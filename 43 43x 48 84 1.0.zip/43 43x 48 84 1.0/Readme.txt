Make sure your printer is well calibrated
Print frame rails down at 100% infill
If the frame warps, reprint
Once rails are installed, frame assemblies like oem